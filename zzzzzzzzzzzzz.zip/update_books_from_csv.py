import pandas as pd
import requests
import os
import time
import logging

# Konfigurasi
CSV_PATH = "zlibrary_scraped_books.csv"  # Ganti jika nama file berbeda
API_URL = "https://www.api.staisenorituban.ac.id/upload_data"  # Ganti jika endpoint berbeda
BATCH_SIZE = 100
MAX_RETRIES = 3

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def clean_dict(d):
    # Bersihkan semua variasi NaN, inf, -inf, string 'nan', 'NaN', 'None', None Python
    cleaned = {}
    for k, v in d.items():
        if v is None:
            cleaned[k] = None
        elif isinstance(v, float):
            if pd.isna(v) or v == float('inf') or v == float('-inf'):
                cleaned[k] = None
            else:
                cleaned[k] = v
        elif isinstance(v, str):
            if v.strip().lower() in ['nan', 'none', 'inf', '-inf', 'null', '']:
                cleaned[k] = None
            else:
                cleaned[k] = v
        else:
            cleaned[k] = v
    return cleaned

def upload_batch_with_retry(batch, max_retries=MAX_RETRIES):
    for attempt in range(1, max_retries + 1):
        try:
            resp = requests.post(API_URL, json=batch, timeout=60)
            if resp.status_code == 404:
                logging.warning(f"[Batch Upload] Attempt {attempt}: 404 Not Found. Retry dalam 5 detik...")
                time.sleep(5)
                continue
            resp.raise_for_status()
            upload_result = resp.json()
            if upload_result.get('status') == 'success':
                logging.info(f"Upload batch {len(batch)} buku ke cloud sukses: {upload_result.get('message')}")
            else:
                logging.warning(f"Upload batch ke cloud gagal: {upload_result}")
            return True
        except Exception as e:
            logging.error(f"[Batch Upload] Attempt {attempt}: Gagal upload batch ke cloud: {e}")
            time.sleep(5)
    logging.error(f"[Batch Upload] Gagal upload batch setelah {max_retries} percobaan.")
    return False

def main():
    if not os.path.exists(CSV_PATH):
        logging.error(f"File CSV tidak ditemukan: {CSV_PATH}")
        return

    df = pd.read_csv(CSV_PATH)
    df = df.where(pd.notnull(df), None)  # Ganti NaN dengan None agar JSON valid
    # Ubah DataFrame ke list of dict
    books = df.to_dict(orient='records')
    logging.info(f"Total buku yang akan diupload: {len(books)}")

    for i in range(0, len(books), BATCH_SIZE):
        batch = [clean_dict(b) for b in books[i:i+BATCH_SIZE]]
        upload_batch_with_retry(batch)
        time.sleep(3)  # Jeda antar batch untuk menghindari rate limit

    logging.info("Selesai upload semua data buku ke API.")

if __name__ == "__main__":
    main()